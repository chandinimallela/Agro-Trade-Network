<?php
include "buyerdatabase.php";
$name=mysqli_real_escape_string($connection,$_POST['loginUser']);
$phone=mysqli_real_escape_string($connection,$_POST['loginnumber']);
$address=mysqli_real_escape_string($connection,$_POST['address']);
if($connection)
{
	echo "connection established";
}
/*$query="CREATE TABLE BUYER (NAME VARCHAR(30) NOT NULL, PHONE VARCHAR(15) NOT NULL, ADDRESS VARCHAR(30) NOT NULL);";
if(mysqli_query($connection,$query))
{
	echo "table created";
}
else
{
	echo "error:".mysqli_error($connection);
}*/
$query1="INSERT INTO BUYER VALUES ('$name','$phone','$address');";
if(mysqli_query($connection,$query1))
{
	echo "record inserted"."<br>";
}
else
{
	echo "error:".mysqli_error($connection);
}
$query2="SELECT * FROM BUYER;";
$check=mysqli_query($connection,$query2);
if(mysqli_num_rows($check))
{
	while($row=mysqli_fetch_assoc($check))
	{
		echo $row['NAME']."  ".$row['PHONE']."  ".$row['ADDRESS']."<br>";
	}
}
header("Location:index1.html");

